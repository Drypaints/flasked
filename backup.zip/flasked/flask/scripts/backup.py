#!/usr/bin/env python

## TODO: implement the backup system in python because I've been told the legacy backup.sh is "insecure"

pass
